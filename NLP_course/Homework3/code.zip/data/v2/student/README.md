# 中文到 Emoji 课程数据 v2 候选版

本包供老师审定后配套作业使用。已修复已知问题并统一编码，尚未完成全量独立人工语义验收。模型与实现限制以老师定稿的作业要求为准，本数据包不额外改变作业要求。

- train.jsonl：120,000条，含id、text、emojis。
- val.jsonl：15,000条，含id、text、emojis。
- test_inputs.jsonl：15,000条，仅含id、text，不提供测试参考。
- emoji_symbol_table.json：依据官方Unicode Emoji 18.0的独立固定符号表。
- ANNOTATION_GUIDE.md：标注约定及合理近似说明，需老师确认。

JSONL为UTF-8，每行一个对象，Emoji为完整单元列表，不能按单个码点拆开。中文词表只在训练集学习；验证集用于调参和选检查点，测试集仅用于最终推理。不得从测试输入学习词表或调参。

提交预测为UTF-8 JSONL，每行包含原始样本id和解码后的emojis列表；所有测试ID各出现一次。保留顺序和重复，排除PAD/BOS/EOS/UNK等特殊Token。若模型立即结束，允许空列表。格式示例（示例ID不是实际样本）：

```json
{"id":"example-only","emojis":["☕","🙏"]}
```

模型须从随机初始化训练。精确匹配和Emoji级F1以老师公布的规范计算，同时分析多种合理表达。
