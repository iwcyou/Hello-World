import argparse
import functools
import json
import os
from pathlib import Path
import platform
import random
import time
import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from src.data import read_rows, build_vocab, collate, decode, write_json, fingerprint, encode, collate_sources
from src.model import Seq2Seq
from src.metrics import metrics

def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

def select_device(name):
    if name == 'auto':
        return torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
    return torch.device(name)

def make_loader(rows, sv, tv, batch_size, shuffle=False):
    return DataLoader(rows, batch_size=batch_size, shuffle=shuffle,
        collate_fn=functools.partial(collate,source_vocab=sv,target_vocab=tv), num_workers=0)

def loss_sum(model, batch, device):
    source, lengths, target = [x.to(device) for x in batch]
    logits = model(source, lengths, target[:, :-1])
    expected = target[:, 1:]
    loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), expected.reshape(-1), ignore_index=0, reduction='sum')
    return loss, int(expected.ne(0).sum())

@torch.no_grad()
def validate_loss(model, loader, device):
    model.eval()
    total = tokens = 0
    for batch in loader:
        loss, n = loss_sum(model, batch, device)
        total += loss.item()
        tokens += n
    return total/tokens

@torch.no_grad()
def predict(model, rows, sv, tv, batch_size, max_steps, device):
    model.eval()
    predictions = []
    for start in range(0,len(rows),batch_size):
        source, lengths = collate_sources(rows[start:start+batch_size],sv)
        generated = model.generate(source.to(device), lengths.to(device), max_steps).cpu().tolist()
        predictions.extend(decode(ids,tv) for ids in generated)
    return predictions

def load_run(directory, device):
    directory = Path(directory)
    config = json.loads((directory/'config.json').read_text())
    vocabs = json.loads((directory/'vocab.json').read_text())
    model = Seq2Seq(len(vocabs['source']),len(vocabs['target']),config['embedding'],config['hidden'],config['dropout']).to(device)
    checkpoint = torch.load(directory/'best.pt',map_location=device,weights_only=True)
    model.load_state_dict(checkpoint['model'])
    model.eval()
    return model, vocabs, config, checkpoint

def train(args):
    out = Path(args.output)
    out.mkdir(parents=True,exist_ok=True)
    if (out/'config.json').exists():
        raise SystemExit('输出目录已有实验配置，请使用新目录，防止覆盖结果')
    seed_all(args.seed)
    torch.set_num_threads(args.threads)
    device = select_device(args.device)
    train_rows, val_rows = read_rows(args.train), read_rows(args.val)
    # 测试集从未在训练入口读取。
    sv = build_vocab([r['text'] for r in train_rows])
    tv = build_vocab([r['emojis'] for r in train_rows])
    max_steps = max(len(r['emojis']) for r in train_rows) + 3
    config = vars(args).copy()
    config.update(device_used=str(device),torch_version=torch.__version__,python=platform.python_version(),
        platform=platform.platform(), max_steps=max_steps,
        train_sha256=fingerprint(args.train),val_sha256=fingerprint(args.val),
        train_count=len(train_rows),val_count=len(val_rows), teacher_forcing=1.,
        source_max_length=max(len(r['text']) for r in train_rows), truncation='none')
    model = Seq2Seq(len(sv),len(tv),args.embedding,args.hidden,args.dropout).to(device)
    config['parameters'] = sum(p.numel() for p in model.parameters())
    write_json(out/'config.json',config)
    write_json(out/'vocab.json',{'source':sv,'target':tv})
    example = train_rows[0]
    write_json(out/'encoding_example.json',{'sample':example,
        'source_ids':encode(example['text'],sv),'source_decoded':''.join(sv[i] for i in encode(example['text'],sv)),
        'decoder_input':[2]+encode(example['emojis'],tv),'target':encode(example['emojis'],tv)+[3],
        'target_decoded':decode(encode(example['emojis'],tv)+[3],tv)})
    loader = make_loader(train_rows,sv,tv,args.batch_size,True)
    vl = make_loader(val_rows,sv,tv,args.batch_size)
    optimizer = torch.optim.Adam(model.parameters(),lr=args.lr)
    best, stale, history = float('inf'), 0, []
    started = time.perf_counter()
    print(json.dumps({'device':str(device),'parameters':config['parameters'],'train':len(train_rows),'val':len(val_rows)}),flush=True)
    for epoch in range(1,args.epochs+1):
        model.train()
        total = tokens = 0
        t = time.perf_counter()
        for step, batch in enumerate(loader,1):
            optimizer.zero_grad(set_to_none=True)
            summed, n = loss_sum(model,batch,device)
            (summed/n).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            optimizer.step()
            total += summed.item()
            tokens += n
            if step % 200 == 0:
                print(f'epoch={epoch} step={step}/{len(loader)} train_loss={total/tokens:.4f}',flush=True)
        validation = validate_loss(model,vl,device)
        # 每轮完整验证集的自主生成指标，与Teacher Forcing损失分开报告。
        predicted = predict(model,val_rows,sv,tv,args.batch_size,max_steps,device)
        score = metrics(predicted,[r['emojis'] for r in val_rows])
        item = {'epoch':epoch,'train_loss':total/tokens,'val_loss':validation,
                'seconds':time.perf_counter()-t,'val_generation':score}
        history.append(item)
        write_json(out/'history.json',history)
        print(json.dumps(item,ensure_ascii=False),flush=True)
        if validation < best - 1e-6:
            best, stale = validation, 0
            torch.save({'model':model.state_dict(),'epoch':epoch,'val_loss':validation},out/'best.pt')
        else:
            stale += 1
        if stale >= args.patience:
            break
    model, vocabs, config, checkpoint = load_run(out,device)
    predictions = predict(model,val_rows,sv,tv,args.batch_size,max_steps,device)
    score = metrics(predictions,[r['emojis'] for r in val_rows])
    # 重载后再次生成，用于验证权重、词表和配置恢复完整。
    reloaded, _, _, _ = load_run(out,device)
    again = predict(reloaded,val_rows[:min(8,len(val_rows))],sv,tv,args.batch_size,max_steps,device)
    assert again == predictions[:len(again)], '保存重载后的生成不一致'
    summary = {'best_epoch':checkpoint['epoch'],'best_val_loss':checkpoint['val_loss'],
        'val_generation':score,'parameters':config['parameters'],'training_seconds':time.perf_counter()-started,
        'reload_verified':True,'device':str(device)}
    write_json(out/'summary.json',summary)
    write_json(out/'val_cases.json',[dict(r,prediction=p) for r,p in zip(val_rows,predictions)])
    plot_history(out,history)
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)

def plot_history(out,history):
    os.environ.setdefault('MPLCONFIGDIR',str(Path('runs/.mplconfig').resolve()))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7,4))
    for key in ('train_loss','val_loss'):
        ax.plot([h['epoch'] for h in history],[h[key] for h in history],label=key)
    ax.set(xlabel='Epoch',ylabel='Cross entropy per non-padding token')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out/'loss.png',dpi=180)
    plt.close(fig)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--train',default='data/v2/prepared/train.jsonl')
    p.add_argument('--val',default='data/v2/prepared/val.jsonl')
    p.add_argument('--output',required=True)
    p.add_argument('--hidden',type=int,default=256)
    p.add_argument('--embedding',type=int,default=128)
    p.add_argument('--dropout',type=float,default=.2)
    p.add_argument('--batch-size',type=int,default=64)
    p.add_argument('--epochs',type=int,default=50)
    p.add_argument('--patience',type=int,default=5)
    p.add_argument('--lr',type=float,default=.001)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--device',choices=['auto','cpu','mps'],default='auto')
    train(p.parse_args())

if __name__=='__main__':
    main()
