import unittest
from src.emoji_standard import load_standard,normalize_units
from scripts.verify_dataset import main

class CurrentDatasetTests(unittest.TestCase):
    def test_current_release_integrity_and_isolation(self):
        main()

    def test_variants_and_invalid_units(self):
        full,_,_=load_standard('data/v2/unicode_emoji_reference.txt')
        self.assertEqual(normalize_units(['❤','☔️'],full),['❤️','☔'])
        with self.assertRaises(ValueError):normalize_units(['abc'],full)
        with self.assertRaises(ValueError):normalize_units(['🦳'],full)

if __name__=='__main__':unittest.main()
