import json
from pathlib import Path
import tempfile
import unittest
from scripts.evaluate_v2_predictions import score_files

class EvaluatorTests(unittest.TestCase):
    def test_alignment_repeats_variants_and_empty_predictions(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            pred=[{'id':'b','emojis':[]},{'id':'a','emojis':['❤','☕','☕']}]
            ref=[{'id':'a','emojis':['❤️','☕']},{'id':'b','emojis':['😊']}]
            for name,rows in [('pred',pred),('ref',ref)]:
                (root/f'{name}.jsonl').write_text('\n'.join(json.dumps(r) for r in rows))
            result=score_files(root/'pred.jsonl',root/'ref.jsonl','data/v2/unicode_emoji_reference.txt')
            self.assertEqual(result['matched_emojis'],2)
            self.assertEqual(result['predicted_emojis'],3)
            self.assertEqual(result['reference_emojis'],3)
            self.assertEqual(result['exact_match'],0)
            self.assertAlmostEqual(result['f1'],2/3)
            (root/'pred.jsonl').write_text(json.dumps({'id':'a','emojis':['☕']}))
            with self.assertRaises(ValueError):score_files(root/'pred.jsonl',root/'ref.jsonl','data/v2/unicode_emoji_reference.txt')
            (root/'pred.jsonl').write_text('\n'.join(json.dumps(r) for r in [pred[0],{'id':'a','emojis':['<UNK>']}]))
            with self.assertRaises(ValueError):score_files(root/'pred.jsonl',root/'ref.jsonl','data/v2/unicode_emoji_reference.txt')
            (root/'pred.jsonl').write_text('\n'.join(json.dumps(r) for r in [pred[0],{'id':'a','emojis':['🧑‍🎮']}]))
            with self.assertRaises(ValueError):score_files(root/'pred.jsonl',root/'ref.jsonl','data/v2/unicode_emoji_reference.txt')

if __name__=='__main__':unittest.main()
