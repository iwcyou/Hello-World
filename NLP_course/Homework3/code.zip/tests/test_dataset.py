import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from scripts.generate_data import parse_rows,canonical
from src.data import write_rows

class DataTests(unittest.TestCase):
    def test_complete_rows_only(self):
        rows,recovered=parse_rows('{"rows":[["想喝咖啡",["☕"]],["今天很开心",["😊"]]}')
        self.assertTrue(recovered)
        self.assertEqual(len(rows),2)
        rows,recovered=parse_rows('{"rows":[["想喝咖啡",["☕"]],["broken')
        self.assertEqual(len(rows),1)
        self.assertTrue(recovered)

    def test_canonical_dedup(self):
        self.assertEqual(canonical('想喝咖啡！'),canonical('想 喝 咖 啡'))

    def test_exact_group_split(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            rows=[]
            for i in range(30):
                for j in range(10+(i%4)):
                    rows.append({'text':f'第{i}组第{j}条喝咖啡','emojis':['☕'],'group':f'group_{i}'})
            write_rows(root/'input.jsonl',rows)
            result=subprocess.run([sys.executable,'scripts/prepare_data.py','--input',str(root/'input.jsonl'),'--output',str(root/'split')],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr+result.stdout)
            sets={}
            for name in ('train','val','test'):
                data=[json.loads(s) for s in (root/'split'/f'{name}.jsonl').read_text().splitlines()]
                sets[name]={r['group'] for r in data}
                if name=='train':self.assertEqual(len(data),int(.8*len(rows)))
                if name=='val':self.assertEqual(len(data),int(.1*len(rows)))
            self.assertFalse(sets['train']&sets['val'])
            self.assertFalse(sets['train']&sets['test'])
            self.assertFalse(sets['val']&sets['test'])

if __name__=='__main__':unittest.main()
