import ast
import inspect
import io
import unittest
import torch
from src.model import ManualLSTMCell,Seq2Seq
from src.data import emoji_units,build_vocab,collate,decode,SPECIAL
from src.metrics import metrics

class CoreTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(42)
        torch.set_num_threads(2)

    def test_gate_equations(self):
        cell=ManualLSTMCell(2,3).double()
        x=torch.randn(2,2,dtype=torch.double)
        h=torch.randn(2,3,dtype=torch.double)
        c=torch.randn(2,3,dtype=torch.double)
        gates=[]
        for wi,wh,b in zip(cell.weight_ih.split(3),cell.weight_hh.split(3),cell.bias.split(3)):
            gates.append(x @ wi.T + h @ wh.T + b)
        i,f,g,o=gates
        expected_c=torch.sigmoid(f)*c+torch.sigmoid(i)*torch.tanh(g)
        expected_h=torch.sigmoid(o)*torch.tanh(expected_c)
        actual_h,actual_c=cell(x,(h,c))
        torch.testing.assert_close(actual_c,expected_c)
        torch.testing.assert_close(actual_h,expected_h)

    def test_finite_difference_gradient(self):
        cell=ManualLSTMCell(2,2).double()
        x=torch.randn(1,2,dtype=torch.double,requires_grad=True)
        h=torch.randn(1,2,dtype=torch.double,requires_grad=True)
        c=torch.randn(1,2,dtype=torch.double,requires_grad=True)
        # 数值差分检查输入/状态以及全部可训练矩阵和偏置。
        def forward(x,h,c,wi,wh,b):
            from torch.func import functional_call
            return functional_call(cell, {'weight_ih':wi,'weight_hh':wh,'bias':b}, (x,(h,c)))
        self.assertTrue(torch.autograd.gradcheck(forward,(x,h,c,cell.weight_ih,cell.weight_hh,cell.bias)))

    def test_padding_freezes_both_states(self):
        model=Seq2Seq(10,8,4,6,0).eval()
        source=torch.tensor([[4,5,0,0],[6,7,8,9]])
        batched=model.encode(source,torch.tensor([2,4]))
        single=model.encode(source[:1,:2],torch.tensor([2]))
        for a,b in zip(batched,single):
            torch.testing.assert_close(a[:1],b)

    def test_unicode_combinations(self):
        self.assertEqual(emoji_units('👩🏽‍💻 🇨🇳 1️⃣ ❤️'),['👩🏽‍💻','🇨🇳','1️⃣','❤️'])
        with self.assertRaises(ValueError):
            emoji_units(['咖啡'])

    def test_shift_and_training_only_vocab(self):
        rows=[{'text':'喝咖啡','emojis':['☕','😊']},{'text':'跑','emojis':['🏃']}]
        sv=build_vocab([r['text'] for r in rows]); tv=build_vocab([r['emojis'] for r in rows])
        _,lengths,target=collate(rows,sv,tv)
        self.assertEqual(lengths.tolist(),[3,1])
        self.assertEqual(target[0,0].item(),2)
        self.assertEqual(target[0,3].item(),3)
        self.assertEqual(decode(target[0,1:].tolist(),tv),rows[0]['emojis'])
        self.assertNotIn('未',sv)

    def test_repeat_and_order_metrics(self):
        result=metrics([['☕','☕'],['😊','☕']],[['☕'],['☕','😊']])
        self.assertEqual(result['matched_emojis'],3)
        self.assertEqual(result['precision'],.75)
        self.assertEqual(result['recall'],1.)
        self.assertEqual(result['exact_match'],0.)

    def test_eos_and_save_reload(self):
        m=Seq2Seq(6,6,4,6,0).eval()
        with torch.no_grad():
            m.output.weight.zero_();m.output.bias.zero_();m.output.bias[3]=10
        x=torch.tensor([[4,5]]);lengths=torch.tensor([2])
        self.assertEqual(m.generate(x,lengths,10).tolist(),[[3]])
        stream=io.BytesIO();torch.save(m.state_dict(),stream);stream.seek(0)
        other=Seq2Seq(6,6,4,6,0).eval()
        other.load_state_dict(torch.load(stream,weights_only=True))
        self.assertEqual(other.generate(x,lengths,10).tolist(),[[3]])

    def test_inference_needs_no_reference(self):
        from train import predict
        model=Seq2Seq(6,6,4,6,0).eval()
        with torch.no_grad():
            model.output.weight.zero_();model.output.bias.zero_();model.output.bias[3]=10
        sv=SPECIAL+['喝','茶'];tv=SPECIAL+['☕','🍵']
        self.assertEqual(predict(model,[{'text':'喝茶'}],sv,tv,1,5,torch.device('cpu')),[[]])

    def test_padding_loss(self):
        from torch.nn import functional as F
        logits=torch.randn(2,3,5)
        target=torch.tensor([[1,2,3],[4,0,0]])
        loss=F.cross_entropy(logits.flatten(0,1),target.flatten(),ignore_index=0,reduction='sum')
        mask=target.ne(0)
        self.assertAlmostEqual(loss.item(),F.cross_entropy(logits[mask],target[mask],reduction='sum').item(),places=5)

    def test_no_builtin_recurrent_cell(self):
        import src.model as module
        tree=ast.parse(inspect.getsource(module))
        banned={'LSTM','LSTMCell','GRU','GRUCell','RNN','RNNCell','_VF'}
        for node in ast.walk(tree):
            if isinstance(node,ast.Attribute):
                self.assertNotIn(node.attr,banned)

    def test_small_set_overfit(self):
        rows=[{'text':'喝咖啡','emojis':['☕']},{'text':'吃苹果','emojis':['🍎']},
              {'text':'去跑步','emojis':['🏃']},{'text':'很开心','emojis':['😊']}]
        sv=build_vocab([r['text'] for r in rows]);tv=build_vocab([r['emojis'] for r in rows])
        source,lengths,target=collate(rows,sv,tv)
        model=Seq2Seq(len(sv),len(tv),12,24,0)
        optimizer=torch.optim.Adam(model.parameters(),lr=.03)
        from torch.nn import functional as F
        for _ in range(150):
            optimizer.zero_grad()
            logits=model(source,lengths,target[:,:-1])
            loss=F.cross_entropy(logits.flatten(0,1),target[:,1:].flatten(),ignore_index=0)
            loss.backward();optimizer.step()
        model.eval()
        outputs=[decode(ids,tv) for ids in model.generate(source,lengths,4).tolist()]
        self.assertEqual(outputs,[r['emojis'] for r in rows])

if __name__=='__main__':
    unittest.main(verbosity=2)
