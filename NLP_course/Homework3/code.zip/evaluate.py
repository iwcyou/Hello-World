"""仅评测验证集选出的最终配置；保存全部案例和20条固定抽样。"""
import argparse
import json
from pathlib import Path
import random
import torch
from train import load_run, predict, select_device
from src.data import read_rows, fingerprint, write_json
from src.metrics import metrics

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--runs',nargs='+',required=True)
    p.add_argument('--test',default='data/v2/prepared/test.jsonl')
    p.add_argument('--output',default='runs/first_training/final')
    p.add_argument('--device',choices=['auto','cpu','mps'],default='auto')
    args=p.parse_args()
    out=Path(args.output)
    if (out/'test_metrics.json').exists():
        raise SystemExit('已有最终测试结果，拒绝覆盖；禁止根据测试结果反复调参')
    candidates=[]
    for run in args.runs:
        summary=json.loads((Path(run)/'summary.json').read_text())
        config=json.loads((Path(run)/'config.json').read_text())
        candidates.append({'run':run,'summary':summary,'config':config})
    if len({(c['config']['train_sha256'],c['config']['val_sha256']) for c in candidates}) != 1:
        raise SystemExit('候选实验的数据划分不同')
    chosen=min(candidates,key=lambda c:c['summary']['best_val_loss'])
    write_json(out/'selection.json',{'criterion':'最低验证集交叉熵','chosen':chosen['run'],'candidates':candidates})
    rows=read_rows(args.test) # 配置选择完成后才读取测试集
    device=select_device(args.device)
    torch.set_num_threads(chosen['config']['threads'])
    model,vocabs,config,_=load_run(chosen['run'],device)
    predictions=predict(model,rows,vocabs['source'],vocabs['target'],config['batch_size'],config['max_steps'],device)
    result=metrics(predictions,[r['emojis'] for r in rows])
    result.update(test_sha256=fingerprint(args.test),chosen_run=chosen['run'],device=str(device))
    result['length_groups']={}
    for low,high,label in [(0,15,'short_1_15'),(16,30,'medium_16_30'),(31,100000,'long_31_plus')]:
        indices=[i for i,r in enumerate(rows) if low <= len(r['text']) <= high]
        if indices:
            result['length_groups'][label]=metrics([predictions[i] for i in indices],[rows[i]['emojis'] for i in indices])
    # 参考词表外Emoji仍保留在参考中，不能映射为UNK后伪造匹配。
    target_set=set(vocabs['target'])
    result['reference_oov_emojis']=sum(e not in target_set for r in rows for e in r['emojis'])
    cases=[dict(r,prediction=pred,exact_match=pred==r['emojis']) for r,pred in zip(rows,predictions)]
    indices=random.Random(42).sample(range(len(cases)),min(20,len(cases)))
    write_json(out/'test_metrics.json',result)
    write_json(out/'all_test_cases.json',cases)
    write_json(out/'sample20.json',[cases[i] for i in indices])
    diagnostics=[{'text':t} for t in ['想喝咖啡','不想喝咖啡','先喝咖啡再去跑步','先去跑步再喝咖啡','今天下雨但我很开心','今天下雨所以我很难过']]
    dp=predict(model,diagnostics,vocabs['source'],vocabs['target'],config['batch_size'],config['max_steps'],device)
    write_json(out/'diagnostics.json',[{'text':r['text'],'prediction':v} for r,v in zip(diagnostics,dp)])
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
