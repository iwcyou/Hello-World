"""UTF-8 JSONL: 每行 {\"text\": \"想喝咖啡\", \"emojis\": [\"☕\"]}。"""
import json
import hashlib
import unicodedata
from collections import Counter
from pathlib import Path
import regex
import torch

SPECIAL = ['<PAD>', '<UNK>', '<BOS>', '<EOS>']

def emoji_units(value):
    if isinstance(value, list):
        units = value
    elif isinstance(value, str):
        units = [u for u in regex.findall(r'\X', value) if not u.isspace()]
    else:
        raise ValueError('emojis 必须为字符串或完整 Emoji 列表')
    for unit in units:
        if not isinstance(unit, str) or regex.fullmatch(r'\X', unit) is None:
            raise ValueError(f'不是单个字素簇: {unit!r}')
        if not regex.search(r'\p{Extended_Pictographic}|\p{Regional_Indicator}|\u20e3', unit):
            raise ValueError(f'不是 Emoji: {unit!r}')
    if not units:
        raise ValueError('Emoji 序列为空')
    return units

def read_rows(path):
    rows = []
    with open(path, encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                text = unicodedata.normalize('NFC', item['text']).strip()
                if not text:
                    raise ValueError('中文为空')
                rows.append({'text': text, 'emojis': emoji_units(item['emojis'])})
            except Exception as e:
                raise ValueError(f'{path}:{line_no}: {e}') from e
    return rows

def write_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def write_rows(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')

def build_vocab(sequences):
    counter = Counter(x for seq in sequences for x in seq)
    return SPECIAL + sorted(counter, key=lambda x: (-counter[x], x))

def encode(seq, vocab):
    ids = {v: i for i, v in enumerate(vocab)}
    return [ids.get(x, 1) for x in seq]

def decode(ids, vocab):
    output = []
    for i in ids:
        if i == 3:
            break
        if i not in (0, 1, 2):
            output.append(vocab[i])
    return output

def collate_sources(rows, source_vocab):
    source_ids = {v:i for i,v in enumerate(source_vocab)}
    sources = [[source_ids.get(c,1) for c in r['text']] for r in rows]
    source = torch.zeros(len(rows), max(map(len, sources)), dtype=torch.long)
    for j, seq in enumerate(sources):
        source[j, :len(seq)] = torch.tensor(seq)
    return source, torch.tensor(list(map(len, sources)))

def collate(rows, source_vocab, target_vocab):
    source, lengths = collate_sources(rows, source_vocab)
    target_ids = {v:i for i,v in enumerate(target_vocab)}
    targets = [[target_ids.get(e,1) for e in r['emojis']] for r in rows]
    target = torch.zeros(len(rows), max(map(len, targets)) + 2, dtype=torch.long)
    for j, t in enumerate(targets):
        target[j, :len(t)+2] = torch.tensor([2] + t + [3])
    return source, lengths, target

def fingerprint(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
