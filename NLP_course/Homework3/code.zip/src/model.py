"""手写单层 LSTM：基础矩阵运算与自动求导，无现成循环单元。"""
import math
import torch
from torch import nn


class ManualLSTMCell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.weight_ih = nn.Parameter(torch.empty(4 * hidden_size, input_size))
        self.weight_hh = nn.Parameter(torch.empty(4 * hidden_size, hidden_size))
        self.bias = nn.Parameter(torch.zeros(4 * hidden_size))
        bound = 1 / math.sqrt(hidden_size)
        nn.init.uniform_(self.weight_ih, -bound, bound)
        nn.init.uniform_(self.weight_hh, -bound, bound)
        with torch.no_grad():
            self.bias[hidden_size:2 * hidden_size].fill_(1.)

    def forward(self, x, state):
        h, c = state
        # 一次矩阵乘法计算四组仿射变换，随后分别执行各门的计算。
        z = x @ self.weight_ih.T + h @ self.weight_hh.T + self.bias
        zi, zf, zg, zo = z.chunk(4, dim=-1)
        i = torch.sigmoid(zi)       # 输入门：允许写入的信息
        f = torch.sigmoid(zf)       # 遗忘门：保留旧记忆的比例
        g = torch.tanh(zg)          # 候选记忆
        o = torch.sigmoid(zo)       # 输出门
        c = f * c + i * g
        h = o * torch.tanh(c)
        return h, c


class Seq2Seq(nn.Module):
    def __init__(self, source_size, target_size, embedding=128, hidden=256, dropout=.2):
        super().__init__()
        self.hidden = hidden
        self.source_embedding = nn.Embedding(source_size, embedding, padding_idx=0)
        self.target_embedding = nn.Embedding(target_size, embedding, padding_idx=0)
        self.encoder = ManualLSTMCell(embedding, hidden)
        self.decoder = ManualLSTMCell(embedding, hidden)
        self.dropout = nn.Dropout(dropout)
        self.output = nn.Linear(hidden, target_size)

    def encode(self, source, lengths):
        x = self.dropout(self.source_embedding(source))
        h = x.new_zeros(source.size(0), self.hidden)
        c = torch.zeros_like(h)
        for t in range(source.size(1)):
            nh, nc = self.encoder(x[:, t], (h, c))
            active = (t < lengths).unsqueeze(-1)
            # Padding 步冻结 h 和 c，等价于分别运行每条真实长度的序列。
            h, c = torch.where(active, nh, h), torch.where(active, nc, c)
        return h, c

    def forward(self, source, lengths, decoder_input):
        state = self.encode(source, lengths)
        x = self.dropout(self.target_embedding(decoder_input))
        outputs = []
        for t in range(decoder_input.size(1)):
            state = self.decoder(x[:, t], state)
            outputs.append(self.output(state[0]))
        return torch.stack(outputs, dim=1)

    @torch.no_grad()
    def generate(self, source, lengths, max_steps):
        state = self.encode(source, lengths)
        token = torch.full((source.size(0),), 2, device=source.device, dtype=torch.long)
        finished = torch.zeros_like(token, dtype=torch.bool)
        result = []
        for _ in range(max_steps):
            nh, nc = self.decoder(self.target_embedding(token), state)
            state = tuple(torch.where(finished[:, None], old, new)
                          for old, new in zip(state, (nh, nc)))
            logits = self.output(state[0])
            logits[:, 0] = -torch.inf
            logits[:, 1] = -torch.inf  # UNK不是可输出Emoji
            logits[:, 2] = -torch.inf
            token = logits.argmax(-1)
            token = torch.where(finished, torch.full_like(token, 3), token)
            result.append(token)
            finished |= token.eq(3)
            if finished.all():
                break
        return torch.stack(result, dim=1)
