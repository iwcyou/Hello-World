from collections import Counter

def metrics(predictions, references):
    if len(predictions) != len(references) or not predictions:
        raise ValueError('需要非空、等长的预测与参考')
    matched = predicted = reference = exact = 0
    for pred, ref in zip(predictions, references):
        exact += pred == ref
        matched += sum((Counter(pred) & Counter(ref)).values())
        predicted += len(pred)
        reference += len(ref)
    p = matched / predicted if predicted else 0.
    r = matched / reference if reference else 0.
    return {'exact_match':exact/len(references),'precision':p,'recall':r,
            'f1':2*p*r/(p+r) if p+r else 0.,'samples':len(references),
            'matched_emojis':matched,'predicted_emojis':predicted,'reference_emojis':reference}
