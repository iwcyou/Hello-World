"""固定 Unicode Emoji 表读取与显示形式规范化。"""
import hashlib
from pathlib import Path

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_standard(path):
    full={};all_forms={};names={}
    for line in Path(path).read_text().splitlines():
        if not line or line.startswith('#'):continue
        head,comment=line.split('#',1)
        code,status=head.split(';');unit=''.join(chr(int(c,16)) for c in code.split())
        status=status.strip();all_forms[unit]=status
        if status=='fully-qualified':
            base=unit.replace('\ufe0f','')
            assert base not in full or full[base]==unit
            full[base]=unit;names[unit]=comment.strip().split(' ',2)[-1]
    return full,all_forms,names

def normalize_units(units,full):
    result=[]
    for unit in units:
        key=unit.replace('\ufe0f','')
        if key in full:
            result.append(full[key]);continue
        # 仅拆解可独立标准化的非标准组合，未知成分必须显式报错。
        components=unit.split('\u200d')
        if len(components)<=1 or not all(c.replace('\ufe0f','') in full for c in components):
            raise ValueError(f'无法安全规范化 {unit!r}')
        result.extend(full[c.replace('\ufe0f','')] for c in components)
    return result
