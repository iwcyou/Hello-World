from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""重新打包当前唯一数据与第一次训练，验证交付指纹与测试答案隔离。"""
import hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path

def main():
    Path('exports').mkdir(exist_ok=True)
    student=Path('data/v2/student')
    manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in student.iterdir() if p.name!='MANIFEST.json'}
    (student/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile('exports/student_data_v2.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(student.iterdir()):z.write(p,p.name)
    subprocess.run([sys.executable,'scripts/package_submission.py'],check=True)
    shutil.copyfile('exports/submission.zip','exports/teacher_data_v2.zip')
    for filename in ('exports/submission.zip','exports/teacher_data_v2.zip','exports/student_data_v2.zip'):
        with zipfile.ZipFile(filename) as z:
            assert z.testzip() is None
            assert not any(n=='.env' or '.venv/' in n or n.startswith(('data/raw/','data/prepared/','runs/h128/','runs/h256/','runs/final/','audit/')) for n in z.namelist())
            if Path(filename).name.startswith('student'):
                rows=[json.loads(x) for x in z.read('test_inputs.jsonl').splitlines()]
                assert len(rows)==15000 and all(set(r)=={'id','text'} for r in rows)
            else:
                for name,entry in json.loads(z.read('MANIFEST.json')).items():
                    blob=z.read(name);assert len(blob)==entry['bytes'] and hashlib.sha256(blob).hexdigest()==entry['sha256'],name
        print(filename,'完整性、指纹、旧数据排除检查通过')

if __name__=='__main__':main()
