from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""教师侧 DeepSeek 合成数据。独立于学生训练/推理，密钥不进入产物。"""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import random
import time
import unicodedata
import urllib.request
import urllib.error
from src.data import emoji_units

TOPICS = ['餐饮与烹饪','学习与考试','工作与会议','运动与健身','出行与交通','天气与季节','家庭与亲友','宠物与动物','旅行与景点','购物与消费','音乐与艺术','健康与休息','节日与庆祝','自然与园艺','科技与通信','家务与生活','游戏与娱乐','校园生活','社交与情绪','城市公共生活']
STYLES = ['简单具体事件，6至16字','对象加动作和情绪，10至25字','先后两个事件，15至35字','否定或愿望表达，8至25字','原因与结果，15至40字','三项有序活动，20至45字','口语化短句，5至18字','带时间地点的具体事件，12至32字']
SYSTEM = '''你是中文到Emoji课程平行语料的生成器。只输出JSON对象，格式 {"rows":[["中文句子",["完整Emoji","完整Emoji"]]]}。
每句自然、具体、独立，包含可由Emoji表达的对象、动作或情绪。Emoji按事件语义顺序排列，通常2至6个，最多10个，允许有意义的重复。标签只包含标准完整Emoji，不含文字标点。使用常见Emoji，正确保留肤色、ZWJ、旗帜。否定用🚫等明确标记，愿望与实际事件有区别。不要补充中文里没有的情节：没有明确情绪不要擅自加笑脸、紧张等情绪，没有明确数量时不要编造数字或时间。避免空泛描述、句子仅替换人名数字、重复模板、机械堆砌。每条句子必须不同，不要解释或Markdown。'''

def api_call(payload, key):
    request = urllib.request.Request('https://api.deepseek.com/chat/completions',
        json.dumps(payload, ensure_ascii=False).encode(),
        {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=180) as r:
            return {'response': json.load(r)}
    except urllib.error.HTTPError as e:
        return {'error': f'HTTP {e.code}'} # 不输出认证信息或服务端响应正文
    except Exception as e:
        return {'error': type(e).__name__}

def parse_rows(content):
    """优先严格JSON；缺末尾括号时仅提取已完整闭合的逐条JSON，不猜测内容。"""
    try:
        obj = json.loads(content)
        if not isinstance(obj.get('rows'), list):
            raise ValueError('rows must be list')
        return obj['rows'], False
    except json.JSONDecodeError:
        import re
        match = re.search(r'"rows"\s*:\s*\[', content)
        if not match:
            raise ValueError('missing rows')
        cursor = match.end()
        decoder = json.JSONDecoder()
        rows = []
        while cursor < len(content):
            while cursor < len(content) and content[cursor] in ' \r\n\t,':
                cursor += 1
            if cursor == len(content) or content[cursor] != '[':
                break
            try:
                row, cursor = decoder.raw_decode(content, cursor)
            except json.JSONDecodeError:
                break
            rows.append(row)
        if not rows:
            raise ValueError('no complete rows')
        return rows, True

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--target', type=int, default=150000)
    p.add_argument('--budget-cny', type=float, default=60)
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--batch-size', type=int, default=100)
    p.add_argument('--max-tokens', type=int, default=6000)
    p.add_argument('--output', default='data/synthetic.jsonl')
    p.add_argument('--max-calls', type=int, default=10000)
    args = p.parse_args()
    if min(args.target, args.workers, args.batch_size, args.max_tokens) <= 0 or not 0 < args.budget_cny <= 60:
        p.error('参数必须为正，费用不得超过已授权60元')
    key = os.getenv('DEEPSEEK_API_KEY')
    if not key and Path('.env').exists():
        for line in Path('.env').read_text().splitlines():
            if line.startswith('DEEPSEEK_API_KEY='):
                key = line.split('=', 1)[1].strip().strip('"').strip("'")
    if not key:
        raise SystemExit('缺少 DEEPSEEK_API_KEY')
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    ledger_path = out.with_suffix('.ledger.json')
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else {
        'model': 'deepseek-flash', 'conservative_cny': 0., 'calls': [],
        'pricing': {'input_per_million_cny': 2., 'output_per_million_cny': 8.,
                    'source': 'https://api-docs.deepseek.com/zh-cn/quick_start/pricing/',
                    'note': '统一按高峰缓存未命中价计；请求失败/中断保留预留费用，实际账单以平台为准'}}
    seen = set()
    accepted = 0
    if out.exists():
        for line in out.read_text().splitlines():
            row = json.loads(line)
            seen.add(canonical(row['text']))
            accepted += 1
    def save():
        temp = ledger_path.with_suffix('.tmp')
        temp.write_text(json.dumps(ledger, ensure_ascii=False, indent=2))
        temp.replace(ledger_path)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool, out.open('a', encoding='utf-8') as f:
        pending = {}
        stop = False
        while accepted < args.target and not stop:
            while len(pending) < args.workers and accepted + len(pending) * args.batch_size < args.target + args.batch_size:
                call_id = len(ledger['calls'])
                if call_id >= args.max_calls:
                    break
                rng = random.Random(20261013 + call_id)
                topic = TOPICS[call_id % len(TOPICS)]
                style = STYLES[(call_id // len(TOPICS)) % len(STYLES)]
                variation = rng.sample(TOPICS, 2)
                prompt = f'生成{args.batch_size}条新样本。主主题：{topic}。形式：{style}。可融合：{variation}。创作批次编号{call_id}，请探索独特具体场景，避免套用固定开头。'
                messages = [{'role':'system','content':SYSTEM}, {'role':'user','content':prompt}]
                # UTF-8字节数是保守输入Token上界，另留消息封装余量。
                input_bound = len(json.dumps(messages, ensure_ascii=False).encode()) + 1024
                reserve = (input_bound * 2 + args.max_tokens * 8) / 1e6
                if ledger['conservative_cny'] + reserve > args.budget_cny:
                    break
                ledger['conservative_cny'] += reserve
                record = {'id':call_id, 'topic':topic, 'style':style, 'reserved_cny':reserve,
                          'status':'reserved', 'request_time':time.time(), 'input_bound':input_bound,
                          'requested_rows':args.batch_size, 'accepted':0}
                ledger['calls'].append(record)
                save() # 先持久化费用预留，进程中断也不会重用预算
                payload = {'model':'deepseek-flash', 'messages':messages, 'temperature':1.1,
                    'max_tokens':args.max_tokens, 'thinking':{'type':'disabled'},
                    'response_format':{'type':'json_object'}}
                pending[pool.submit(api_call, payload, key)] = record
            if not pending:
                break
            ready, _ = concurrent.futures.wait(pending, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in ready:
                record = pending.pop(future)
                result = future.result()
                if 'error' in result:
                    record.update(status='failed_reserved', error=result['error'])
                    if result['error'] in ('HTTP 401','HTTP 402','HTTP 403','HTTP 400','HTTP 404'):
                        stop = True
                else:
                    response = result['response']
                    usage = response.get('usage')
                    if usage and 'prompt_tokens' in usage and 'completion_tokens' in usage:
                        charged = (usage['prompt_tokens'] * 2 + usage['completion_tokens'] * 8) / 1e6
                        ledger['conservative_cny'] += charged - record['reserved_cny']
                        record['usage'] = usage
                        record['conservative_cny'] = charged
                    record['model_returned'] = response.get('model')
                    record['response_id'] = response.get('id')
                    try:
                        choice = response['choices'][0]
                        record['finish_reason'] = choice.get('finish_reason')
                        content = choice['message']['content']
                        raw_dir = out.parent / 'raw'
                        raw_dir.mkdir(exist_ok=True)
                        (raw_dir / f'{record["id"]:06d}.json').write_text(json.dumps(response, ensure_ascii=False), encoding='utf-8')
                        items, recovered = parse_rows(content)
                        record['recovered_complete_rows'] = recovered
                        if not isinstance(items, list):
                            raise ValueError('rows must be list')
                        rejected = {}
                        for item in items:
                            try:
                                if not isinstance(item, list) or len(item) != 2 or not isinstance(item[0], str):
                                    raise ValueError('schema')
                                text = unicodedata.normalize('NFC', item[0]).strip()
                                if not 5 <= len(text) <= 60 or not any('\u4e00' <= x <= '\u9fff' for x in text):
                                    raise ValueError('text_length_or_language')
                                if any(regex_emoji(text)):
                                    raise ValueError('emoji_in_source')
                                units = emoji_units(item[1])
                                if len(units) > 10:
                                    raise ValueError('target_length')
                                canon = canonical(text)
                                if canon in seen:
                                    raise ValueError('duplicate')
                                if accepted >= args.target:
                                    break
                                row = {'text':text, 'emojis':units, 'group':f'batch_{record["id"]}',
                                       'topic':record['topic'], 'style':record['style'], 'model':response.get('model')}
                                f.write(json.dumps(row, ensure_ascii=False) + '\n')
                                seen.add(canon)
                                accepted += 1
                                record['accepted'] += 1
                            except (ValueError, TypeError) as e:
                                reason = str(e).split(':')[0]
                                rejected[reason] = rejected.get(reason, 0) + 1
                        record['rejected'] = rejected
                        record['status'] = 'complete'
                    except (ValueError, KeyError, TypeError, IndexError) as e:
                        record.update(status='invalid_response', error=type(e).__name__)
                f.flush()
                ledger['accepted'] = accepted
                save()
                print(json.dumps({'accepted':accepted,'target':args.target,'calls':len(ledger['calls']),
                    'budget_accounted_cny':round(ledger['conservative_cny'],4),'last_status':record['status']},ensure_ascii=False), flush=True)
        # 通常只在终止错误时存在在途请求，仍需结算并保留响应。
        for future, record in pending.items():
            result = future.result()
            record['status'] = 'completed_after_stop_reserved'
            if 'response' in result:
                raw_dir = out.parent / 'raw'
                raw_dir.mkdir(exist_ok=True)
                (raw_dir / f'{record["id"]:06d}.json').write_text(json.dumps(result['response'], ensure_ascii=False))
        save()
    print('完成/停止：', accepted, '条；保守计费', round(ledger['conservative_cny'],4), '元', flush=True)

def canonical(text):
    import regex
    return regex.sub(r'[\p{P}\p{Z}\s]', '', unicodedata.normalize('NFKC', text)).lower()

def regex_emoji(text):
    import regex
    return regex.findall(r'\p{Extended_Pictographic}|\p{Regional_Indicator}', text)

if __name__ == '__main__':
    main()
