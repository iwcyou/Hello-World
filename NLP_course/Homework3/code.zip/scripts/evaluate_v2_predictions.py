from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""教师侧通用评测：对齐样本ID，核验完整Emoji，计算micro指标。"""
import argparse
import json
from pathlib import Path
import regex
from src.emoji_standard import load_standard,normalize_units,digest
from src.metrics import metrics

def read_jsonl(path):
    rows={}
    with open(path,encoding='utf-8') as f:
        for number,line in enumerate(f,1):
            if not line.strip():continue
            row=json.loads(line);key=row.get('id')
            if not isinstance(key,str) or not key:raise ValueError(f'{path}:{number}:缺少id')
            if key in rows:raise ValueError(f'{path}:{number}:重复id {key}')
            if not isinstance(row.get('emojis'),list):raise ValueError(f'{path}:{number}:emojis须为列表')
            rows[key]=row
    return rows

def score_files(prediction_path,reference_path,unicode_path):
    full,_,_=load_standard(unicode_path)
    predictions=read_jsonl(prediction_path);references=read_jsonl(reference_path)
    if set(predictions)!=set(references):
        raise ValueError(f'样本ID不完整：缺失{len(set(references)-set(predictions))}，多出{len(set(predictions)-set(references))}')
    def valid(seq):
        for unit in seq:
            if not isinstance(unit,str) or regex.fullmatch(r'\X',unit) is None or unit.replace('\ufe0f','') not in full:
                raise ValueError(f'不是合法完整Emoji：{unit!r}；输出前须解码并排除特殊Token')
        return normalize_units(seq,full)
    ids=sorted(references)
    result=metrics([valid(predictions[k]['emojis']) for k in ids],[valid(references[k]['emojis']) for k in ids])
    result.update(predictions_sha256=digest(prediction_path),references_sha256=digest(reference_path),
                  normalization='Unicode fully-qualified等价规范化；不改变顺序与重复次数',data_version='2.0')
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--predictions',required=True)
    p.add_argument('--references',default='data/v2/prepared/test.jsonl')
    p.add_argument('--unicode',default='data/v2/unicode_emoji_reference.txt')
    p.add_argument('--output')
    args=p.parse_args()
    result=score_files(args.predictions,args.references,args.unicode)
    if args.output:
        path=Path(args.output)
        if path.resolve() in {Path(args.predictions).resolve(),Path(args.references).resolve()}:
            raise ValueError('输出不能覆盖预测或参考输入')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
