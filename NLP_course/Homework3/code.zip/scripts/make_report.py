from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""根据当前首次训练的真实产物生成报告。"""
import json
from pathlib import Path
from collections import Counter

def read(path): return json.loads(Path(path).read_text())
def pct(value): return f'{100*value:.2f}%'
def table(headers,rows):
    def escape(value): return str(value).replace('|','\\|').replace('\n',' ')
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(escape,row))+' |' for row in rows])

def main(base=Path('runs/first_training')):
    selection=read(base/'final/selection.json');score=read(base/'final/test_metrics.json')
    chosen=Path(selection['chosen']);config=read(chosen/'config.json');vocab=read(chosen/'vocab.json')
    release=read('data/v2/release.json');stats=read('data/v2/prepared/statistics.json')
    candidates=selection['candidates'];examples=read(base/'final/sample20.json')
    parts=['# 中文到 Emoji 的手写 LSTM 序列生成实验报告：第一次训练',
        '本报告记录当前固定数据集上的第一次正式训练。两种隐藏维度均从随机初始化开始，不加载预训练权重。报告数字均读取本次保存的配置、训练历史、最佳检查点和最终测试结果。',
        f"按最低验证交叉熵选择隐藏维度 **{config['hidden']}** 的模型。测试集完全匹配率 **{pct(score['exact_match'])}**，Emoji 级 micro F1 **{pct(score['f1'])}**。这些指标衡量与合成参考标签的匹配程度，不能单独证明中文语义理解能力。",
        '## 1 数据与固定划分',
        '采用当前修订后的150,000条中文—Emoji配对，覆盖20个生成主题和8种句式。目标统一为固定Unicode Emoji 18.0 fully-qualified形式；每个目标单元为完整Emoji，保留ZWJ、肤色、旗帜、键帽、重复次数和顺序。',
        '生成批次和已检出的近重复句族整组隔离，固定随机种子42。划分只按主题、句式和长度元信息平衡，未按模型测试分数选取。规范化源句精确重复为0；已检出的近重复关系跨集合为0。这不保证所有语义近义改写都已检出。',
        table(['集合','样本数','比例','组数','中文长度均值','Emoji长度均值'],[[name,s['count'],f"{s['count']/1500:.0f}%",s['groups'],f"{s['source_length']['mean']:.2f}",f"{s['target_length']['mean']:.2f}"] for name,s in stats['splits'].items()]),
        f"仍有{release['pending_rule_candidates']:,}条弱规则候选待复核。当前数据未完成全量独立人工语义验收；规则命中不等于错误，未命中也不等于正确。无直接Emoji的对象及否定范围表达约定见 `data/v2/ANNOTATION_GUIDE.md`。本轮训练未调用付费API。",
        '## 2 编码与手写模型',
        f"中文按字符编码，中文词表{len(vocab['source'])}项，Emoji词表{len(vocab['target'])}项，均包含PAD/UNK/BOS/EOS四个特殊Token且只从训练集建立。输入不截断，测试参考中训练词表外Emoji出现{score['reference_oov_emojis']}次，参考保留原符号参与评测。",
        '单层、单向、无Attention的LSTM Encoder–Decoder。编码器最终h和c初始化解码器；达到真实输入长度后冻结h和c，避免PAD污染。LSTM门控、状态更新与时间步循环在src/model.py中手写，使用PyTorch基础张量、自动求导和Adam，不调用内置LSTM/LSTMCell。',
        '```text\nz = x @ W_ih.T + h_prev @ W_hh.T + b\ni, f, g, o = sigmoid(z_i), sigmoid(z_f), tanh(z_g), sigmoid(z_o)\nc = f * c_prev + i * g\nh = o * tanh(c)\n```',
        '## 3 训练与模型选择',
        f"Embedding={config['embedding']}，Dropout={config['dropout']}，batch={config['batch_size']}，Adam学习率={config['lr']}，梯度裁剪1.0，随机种子{config['seed']}，最多{config['epochs']}轮，验证损失连续{config['patience']}轮未改善早停。实际设备为{config['device_used']}，Python {config['python']}，PyTorch {config['torch_version']}。",
        '训练采用完整Teacher Forcing，目标右移并加入BOS/EOS；交叉熵忽略PAD，按有效Token数加权平均。每轮另在完整验证集自主生成。推理从BOS开始贪心解码，屏蔽PAD/UNK/BOS，遇EOS或训练集最大目标长度加3停止。',
        '128与256维只改变隐藏维度，其他条件保持一致。每个模型按最低验证损失保存最佳权重；两个模型也按该指标选取最终配置，选定后才读取测试参考。早停轮数不同，因此并非严格等计算预算对照。',
        table(['隐藏维度','参数量','实际轮数','最佳轮次','验证损失','验证EM','验证F1','训练分钟'],[[c['config']['hidden'],c['summary']['parameters'],len(read(Path(c['run'])/'history.json')),c['summary']['best_epoch'],f"{c['summary']['best_val_loss']:.4f}",pct(c['summary']['val_generation']['exact_match']),pct(c['summary']['val_generation']['f1']),f"{c['summary']['training_seconds']/60:.2f}"] for c in candidates]),
        '验证交叉熵与自主生成F1不必同向变化。本实验仅一个随机种子，不将两种配置的差异解释为统计显著差异。模型保存并重新加载后验证固定输入输出一致。',
        f'![128维损失曲线]({base}/h128/loss.png)\n\n![256维损失曲线]({base}/h256/loss.png)',
        '## 4 最终测试',
        table(['样本数','完全匹配率','Precision','Recall','F1'],[[score['samples']]+[pct(score[k]) for k in ('exact_match','precision','recall','f1')]]),
        '完全匹配要求顺序、符号和重复次数一致。Emoji级micro指标先在每条样本内按多重集合计算交集，再跨样本汇总；不同样本不能互相抵消。F1忽略顺序，须结合完全匹配率观察。当前训练和参考均使用统一的完整Emoji写法，PAD/UNK/BOS/EOS排除。',
        table(['中文长度组','样本数','完全匹配率','F1'],[[name,m['samples'],pct(m['exact_match']),pct(m['f1'])] for name,m in score['length_groups'].items()]),
        '长度组同时包含主题、目标长度和难度差异，不能只依据组间差异推断长程记忆能力。',
        '## 5 固定抽样与误差分析',
        '以下20条用种子42从本次测试集随机抽样，没有按输出好坏筛选。遗漏与新增表示相对参考的差异，仍需结合中文判断合理替代和核心事件覆盖。']
    rows=[]
    counts=Counter()
    for n,r in enumerate(examples,1):
        ref,pred=r['emojis'],r['prediction'];missing=list((Counter(ref)-Counter(pred)).elements());extra=list((Counter(pred)-Counter(ref)).elements())
        if ref==pred: note='完全一致';counts['完全一致']+=1
        elif not missing and not extra:note='符号与次数相同，顺序不同';counts['仅顺序差异']+=1
        else:
            note='遗漏：'+(''.join(missing) or '无')+'；新增：'+(''.join(extra) or '无')
            counts['存在参考符号差异']+=1
        rows.append([n,r['text'],''.join(ref),''.join(pred),note])
    parts += [table(['编号','中文','参考','输出','参考差异'],rows),
        f"抽样分类：{dict(counts)}。单一参考不能覆盖所有合理Emoji表达；数量与顺序正确也不保证否定范围和事件关系正确。固定状态压缩、Teacher Forcing与自主生成的分布差异，以及标签噪声都可能影响结果。",
        '具体观察：第1条遗漏手工活动，并新增手机；第4条在镜框镜片场景中新增相机；第12条只输出一个电池，未保留两节的数量；第14条保留游泳，但遗漏先冲淋和最后擦干两个阶段；第16条未表达手机被偷，将充电情境输出为低电量。这些例子显示核心事件、数量及因果关系仍可能丢失。第9条基本保留萝卜、坛子、盐与家庭人物，但角色和顺序仍需结合中文判断。',
        '最小差异诊断仅作定性观察，不用于再次调参：',
        table(['中文','输出'],[[r['text'],''.join(r['prediction'])] for r in read(base/'final/diagnostics.json')]),
        '本次诊断中，咖啡与跑步的次序随输入次序改变，但后一条新增了放松表情；不想喝咖啡输出了否定符号，同时重复咖啡；下雨难过句加入原文没有的否定符号。模型在这些样例中表现出局部顺序敏感性，但否定范围、额外符号和重复生成仍不稳定。六条诊断不足以概括总体能力。',
        '## 6 正确性、复现与文件指纹',
        '正确性检查包括门控公式、有限差分梯度、Padding状态冻结、Emoji完整单元、目标移位、重复与顺序指标、EOS终止、保存重载、小样本拟合，以及当前数据的数量、编码、ID、指纹和划分隔离。执行日志见runs/first_training/correctness.txt。',
        '```bash\n.venv/bin/python -m unittest discover -s tests -v\n.venv/bin/python run_experiment.py --device auto\n```',
        '上述流水线拒绝覆盖已有配置；复现实验使用 `--output` 指定新的独立目录。默认报告和提交包对应runs/first_training。测试集仅用于最后评测，不用于词表建立、训练或配置挑选。',
        table(['输入','SHA-256'],[['train',config['train_sha256']],['val',config['val_sha256']],['test',score['test_sha256']]]),
        '权重、词表、配置、逐轮指标和曲线位于runs/first_training/h128及h256；最终选择、全部测试输出、固定20条和诊断位于runs/first_training/final。提交包通过exports/MANIFEST.json提供逐文件指纹。',
        '本报告仅呈现当前第一次正式训练。数据为合成参考，尚非全量人工金标准；应结合实现正确性、案例分析和复现性评价实验，不将单一匹配分数当作语义理解能力。']
    Path('REPORT.md').write_text('\n\n'.join(parts)+'\n')
    print('REPORT.md 已由第一次训练真实产物生成')

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--runs-root',type=Path,default=Path('runs/first_training'))
    main(parser.parse_args().runs_root)
