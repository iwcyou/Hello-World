from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

import argparse
import json
import time
import torch
from src.model import Seq2Seq

p=argparse.ArgumentParser()
p.add_argument('--steps',type=int,default=10)
args=p.parse_args()
torch.set_num_threads(4)
results=[]
for device in ['cpu']+(['mps'] if torch.backends.mps.is_available() else []):
    for hidden in (128,256):
        for batch in (64,256):
            model=Seq2Seq(4000,400,128,hidden,.2).to(device)
            source=torch.randint(4,4000,(batch,32),device=device)
            lengths=torch.full((batch,),32,device=device)
            target=torch.randint(4,400,(batch,7),device=device)
            opt=torch.optim.Adam(model.parameters(),lr=.001)
            for step in range(args.steps+2):
                if step==2:
                    if device=='mps': torch.mps.synchronize()
                    start=time.perf_counter()
                opt.zero_grad(set_to_none=True)
                logits=model(source,lengths,target[:,:-1])
                loss=torch.nn.functional.cross_entropy(logits.flatten(0,1),target[:,1:].flatten())
                loss.backward();opt.step()
            if device=='mps': torch.mps.synchronize()
            seconds=(time.perf_counter()-start)/args.steps
            item={'device':device,'hidden':hidden,'batch':batch,'seconds_per_step':seconds,'samples_per_second':batch/seconds}
            results.append(item)
            print(json.dumps(item),flush=True)
from src.data import write_json
write_json('runs/benchmark.json',results)
