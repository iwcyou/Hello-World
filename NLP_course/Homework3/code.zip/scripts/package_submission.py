from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""仅打包当前数据与第一次训练，排除密钥、虚拟环境和旧实验。"""
import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parents[1]
required=['REPORT.md','README.md','runs/first_training/h128/best.pt','runs/first_training/h256/best.pt','runs/first_training/final/test_metrics.json','data/v2/prepared/verification.json','runs/first_training/correctness.txt']
for name in required:
    if not (root/name).is_file():raise SystemExit(f'缺少必需产物: {name}')
if json.loads((root/'data/v2/prepared/verification.json').read_text())['total']!=150000:raise SystemExit('数据量不符')
if '\nOK\n' not in (root/'runs/first_training/correctness.txt').read_text():raise SystemExit('检查未通过')
(root/'exports').mkdir(exist_ok=True)
files=set()
for pattern in ('*.py','*.md','requirements*.txt','*.docx','src/*.py','scripts/*.py','tests/*.py','docs/*','data/v2/**/*','runs/first_training/**/*'):
    files.update(p for p in root.glob(pattern) if p.is_file() and '__pycache__' not in p.parts)
assert not any(p.name=='.env' or '.venv' in p.parts for p in files)
manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)}
(root/'exports/MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(root/'exports/submission.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,str(p.relative_to(root)))
    z.write(root/'exports/MANIFEST.json','MANIFEST.json')
with zipfile.ZipFile(root/'exports/submission.zip') as z:assert z.testzip() is None
print('submission.zip:',(root/'exports/submission.zip').stat().st_size,'bytes;',len(files)+1,'files')
