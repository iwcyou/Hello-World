from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""核验当前唯一数据集的固定划分、指纹、编码与学生测试输入。"""
import json
from pathlib import Path
from src.emoji_standard import load_standard,digest
from scripts.generate_data import canonical
from src.data import write_json

def main():
    root=Path('data/v2');release=json.loads((root/'release.json').read_text());full,forms,_=load_standard(root/'unicode_emoji_reference.txt')
    assignments={};texts={};families={};batches={};counts={};test={};split_rows={}
    assert digest(root/'synthetic.jsonl')==release['source_v2_sha256']
    for name,expected in [('train',120000),('val',15000),('test',15000)]:
        path=root/'prepared'/f'{name}.jsonl';assert digest(path)==release['splits'][name]['sha256']
        rows=[json.loads(x) for x in path.read_text().splitlines()];assert len(rows)==expected;counts[name]=len(rows)
        for r in rows:
            assert r['id'] not in assignments;assignments[r['id']]=name;split_rows[r['id']]=r
            key=canonical(r['text']);assert key not in texts;texts[key]=name
            assert 5<=len(r['text'])<=60 and 1<=len(r['emojis'])<=10
            assert all(forms.get(u)=='fully-qualified' for u in r['emojis'])
            for field,mapping in [('group',families),('generation_group',batches)]:assert mapping.setdefault(r[field],name)==name
            if name=='test':test[r['id']]=r['text']
    source=[json.loads(x) for x in (root/'synthetic.jsonl').read_text().splitlines()]
    assert len(source)==150000 and {r['id'] for r in source}==set(assignments)
    assert all(r==split_rows[r['id']] for r in source)
    for line in (root/'pending_review.jsonl').read_text().splitlines():
        r=json.loads(line);current=split_rows[r['id']]
        assert r['text']==current['text'] and r['emojis']==current['emojis']
    for line in (root/'near_duplicate_families.jsonl').read_text().splitlines():
        pair=json.loads(line);assert assignments[source[pair['a']]['id']]==assignments[source[pair['b']]['id']]
    student=[json.loads(x) for x in (root/'student/test_inputs.jsonl').read_text().splitlines()]
    assert len(student)==15000 and all(set(r)=={'id','text'} for r in student)
    assert {r['id']:r['text'] for r in student}==test
    result={'total':150000,'counts':counts,'canonical_text_overlap':False,'generation_group_overlap':False,'detected_near_pair_overlap':False,'student_test_labels':False,'fingerprints_verified':True}
    write_json(root/'prepared/verification.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
