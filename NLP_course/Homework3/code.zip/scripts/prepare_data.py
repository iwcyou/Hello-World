from pathlib import Path as _Path
import sys as _sys
_sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

"""清洗后的教师语料按生成批次分组划分，保存固定数据指纹与统计。"""
import argparse
from collections import defaultdict, Counter
import json
from pathlib import Path
import random
import numpy as np
from src.data import read_rows, write_rows, write_json, fingerprint
from scripts.generate_data import canonical

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', default='data/synthetic.jsonl')
    p.add_argument('--output', default='data/prepared')
    p.add_argument('--seed', type=int, default=42)
    args = p.parse_args()
    rows = read_rows(args.input)
    # read_rows 校验内容后重新带回教师侧元数据。
    originals = [json.loads(x) for x in Path(args.input).read_text().splitlines() if x.strip()]
    groups = defaultdict(list)
    seen = set()
    for i, (row, original) in enumerate(zip(rows, originals)):
        key = canonical(row['text'])
        if key in seen:
            continue
        seen.add(key)
        row.update({k:original[k] for k in ('group','topic','style') if k in original})
        groups[original.get('group', f'row_{i}')].append(row)
    keys = sorted(groups)
    random.Random(args.seed).shuffle(keys)
    if len(keys) < 10:
        raise SystemExit('至少需要10个独立生成批次，才能建立有效的训练/验证/测试划分')
    # 保持整组隔离，同时精确满足样本数比例。
    n = len(keys)
    total = sum(len(groups[k]) for k in keys)
    n_train, n_val = int(.8*total), int(.1*total)
    n_test = total-n_train-n_val
    def choose_groups(candidates, desired):
        # 位集合子集和：精确满足样本数，同时整批隔离。
        reachable = 1
        snapshots = []
        limit = (1 << (desired+1))-1
        for key in candidates:
            snapshots.append((key, reachable))
            reachable |= (reachable << len(groups[key])) & limit
            if (reachable >> desired) & 1:
                break
        if not ((reachable >> desired) & 1):
            raise SystemExit('无法在保持批次隔离的同时精确划分，请增加独立生成批次')
        selected = []
        remaining = desired
        for key, before in reversed(snapshots):
            if not ((before >> remaining) & 1):
                selected.append(key)
                remaining -= len(groups[key])
        assert remaining == 0
        return selected
    val_keys = choose_groups(keys, n_val)
    val_set = set(val_keys)
    rest = [k for k in keys if k not in val_set]
    test_keys = choose_groups(rest, n_test)
    test_set = set(test_keys)
    partitions = {'train':[k for k in rest if k not in test_set], 'val':val_keys,'test':test_keys}
    summary = {'seed':args.seed, 'source_sha256':fingerprint(args.input), 'input_count':len(rows),
        'deduplicated_count':len(seen), 'group_count':n,
        'split_policy':'按生成批次整组隔离，子集和精确满足80/10/10样本数（向下取整后余数归测试集）', 'splits':{}}
    out = Path(args.output)
    for name, group_keys in partitions.items():
        part = [r for k in group_keys for r in groups[k]]
        path = out / f'{name}.jsonl'
        write_rows(path, part)
        def describe(values):
            return {'min':min(values),'max':max(values),'mean':float(np.mean(values)),
                    'p50':float(np.percentile(values,50)),'p95':float(np.percentile(values,95))}
        summary['splits'][name] = {'count':len(part), 'ratio':len(part)/len(seen),'groups':len(group_keys),
            'source_length':describe([len(r['text']) for r in part]),
            'target_length':describe([len(r['emojis']) for r in part]),
            'unique_characters':len(set(''.join(r['text'] for r in part))),
            'unique_emojis':len(set(e for r in part for e in r['emojis'])),
            'topics':dict(Counter(r.get('topic','unknown') for r in part)), 'sha256':fingerprint(path)}
    write_json(out/'statistics.json',summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
