import argparse
import json
import torch
from src.data import encode
from train import load_run,select_device,predict

p=argparse.ArgumentParser()
p.add_argument('--run',required=True)
p.add_argument('--text')
p.add_argument('--device',choices=['auto','cpu','mps'],default='auto')
args=p.parse_args()
device=select_device(args.device)
model,vocabs,config,_=load_run(args.run,device)
torch.set_num_threads(config['threads'])

def answer(text):
    if not text.strip():
        return
    result=predict(model,[{'text':text}],vocabs['source'],vocabs['target'],1,config['max_steps'],device)[0]
    print(json.dumps({'text':text,'emojis':result,'output':''.join(result),
        'unknown_characters':[c for c in text if c not in set(vocabs['source'])]},ensure_ascii=False))

if args.text:
    answer(args.text)
else:
    while True:
        try:
            answer(input('中文（Ctrl-D退出）> '))
        except EOFError:
            break
