"""当前固定数据上的首次训练流水线；所有模型从随机初始化开始。"""
import argparse
from pathlib import Path
import subprocess
import sys
import time
from src.data import write_json

p=argparse.ArgumentParser()
p.add_argument('--device',default='auto',choices=['auto','mps','cpu'])
p.add_argument('--output',default='runs/first_training')
args=p.parse_args();root=Path(args.output)
if any((root/name/'config.json').exists() for name in ('h128','h256')):
    raise SystemExit('已有训练配置；复现请通过--output指定新的独立目录')
root.mkdir(parents=True,exist_ok=True);started=time.time()
def execute(stage,command):
    write_json(root/'pipeline_status.json',{'stage':stage,'status':'running','started':started,'command':command})
    with (root/f'{stage}.log').open('w') as f:
        result=subprocess.run([sys.executable]+command,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode:
        write_json(root/'pipeline_status.json',{'stage':stage,'status':'failed','exit_code':result.returncode})
        raise SystemExit(f'{stage}失败，见{root/stage}.log')
execute('verify_dataset',['scripts/verify_dataset.py'])
for hidden in (128,256):
    execute(f'h{hidden}',['train.py','--hidden',str(hidden),'--batch-size','256','--device',args.device,'--output',str(root/f'h{hidden}')])
execute('final',['evaluate.py','--runs',str(root/'h128'),str(root/'h256'),'--device',args.device,'--output',str(root/'final')])
execute('report',['scripts/make_report.py','--runs-root',str(root)])
write_json(root/'pipeline_status.json',{'stage':'all','status':'complete','seconds':time.time()-started})
